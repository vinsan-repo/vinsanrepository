import urlquick
import re
import json
import ast

resp = urlquick.get("https://0gomovies.li/genre/tamil-movies/", max_age=-1, verify = False)
movies_list = resp.parse(
        "div", attrs={"class": "movies-list movies-list-full"})
print(movies_list)