# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from codequick.script import Settings
import urlquick
import xbmc
import xbmcgui
import xbmcaddon
import re
import os

ADDON = xbmcaddon.Addon()

channels = [
  {
    'language': 'Tamil',
    'thumbnail': os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources", "images", "tamil.png"),
    'url': Settings.get_string('baseUrl')+'genre/tamil-movies/'
  },
  {
    'language': 'Malayalam',
    'thumbnail': os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources", "images", "malayalam.png"),
    'url': Settings.get_string('baseUrl')+'genre/malayalam-movies/'
  },
  {
    'language': 'Telugu',
    'thumbnail': os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources", "images", "tamil.png"),
    'url': Settings.get_string('baseUrl')+'genre/telugu/'
  },
  {
    'language': 'Hindi',
    'thumbnail': os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources", "images", "malayalam.png"),
    'url': Settings.get_string('baseUrl')+'genre/hindi/'
  }
]

@Route.register
def root(plugin, content_type="segment"):
    for e in channels:
        yield Listitem.from_dict(**{
            "label": e.get('language'),
            "art": {
                "thumb": e.get('thumbnail'),
                "icon": e.get('thumbnail'),
                "fanart": e.get('thumbnail'),
            },
            "callback": Route.ref("/resources/lib/main:get_movie_list"),
            "params": {"url": e.get('url')}
        })    

@Route.register
def get_movie_list(plugin,url):
    resp = urlquick.get(url, max_age=-1, verify = False)
    movies_list = resp.parse(
        "div", attrs={"class": "movies-list movies-list-full"})
    movie_items = movies_list.iterfind("div/a")

    for movie_item in movie_items:
        item = Listitem()
        temp_link = movie_item.get("href")
        temp_image = movie_item.find("img")

        item.label = temp_image.get("alt")
        item.art['thumb'] = temp_image.get("data-src")
        item.art['fanart'] = temp_image.get("data-src")
        item.set_callback(play_video, movie_name=temp_image.get("alt"), movie_img=temp_image.get("data-src"), url=temp_link)
        yield item

    next_page_tree = resp.parse("ul", attrs={"class": "pagination"})
    next_page_p = next_page_tree.find("li[last()-1]/a")

    yield Listitem.next_page(url=next_page_p.get("href"), callback=get_movie_list)

@Resolver.register
def play_video(plugin, movie_name, movie_img, url):
    resp = urlquick.get(url+'/watching', max_age=-1, verify = False)
    server_list = resp.parse("ul", attrs={"id": "servers-list"})
    drive_server = server_list.find("li[@data-drive]")

    player_url = drive_server.get('data-drive')

    player_url_res = urlquick.get(player_url, max_age=-1, verify = False, headers={'referer': Settings.get_string("baseUrl")})
    m3u8_url = re.search(r'(?s)(?<=file:)(.*)(?=}],)', player_url_res.text).group(0)
    m3u8_url = m3u8_url.replace('"','')

    return Listitem().from_dict(**{
      'label': movie_name,
      'art': {
        'thumb': movie_img
      },      
      'callback': m3u8_url
    })