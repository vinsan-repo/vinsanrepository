import urlquick
import re
import json
import ast

resp = urlquick.get("https://api.thingspeak.com/channels/1409854/feeds.json?api_key=FNQOUSCHIVJUDJZ4", max_age=-1, verify = False)
json_resp = resp.json()
print (json_resp['feeds'])