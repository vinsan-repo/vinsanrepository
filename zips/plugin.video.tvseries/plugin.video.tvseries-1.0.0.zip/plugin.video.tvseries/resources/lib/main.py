# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from codequick.script import Settings
import urlquick
import xbmc
import xbmcgui
import xbmcaddon
import re
import os

ADDON = xbmcaddon.Addon()
baseUrl = Settings.get_string('mh_base_url')
shows = [
  {
    'title': 'Money Heist',
    'id': 'moneyheist',
    'seasons': [
      {
        'title': 'Season 01',
        'url': 'tv/htp-a-money-heist-season-1-online-gomovies/watching/'
      },
      {
          'title': 'Season 02',
          'url': 'tv/hdiv-money-heist-season-2-online-gomovies/watching/'
      },
      {
          'title': 'Season 03',
          'url': 'tv/watch-money-heist-season-3-online-gomovies/watching/'
      }
    ]
  }
]


def get_episodes(url):    
    resp = urlquick.get(f'{baseUrl}{url}', max_age=-1, verify=False)
    episode_list = resp.parse("div", attrs={"class": "pas-list"})
    eps = {}
    for ep_server in episode_list.iterfind('ul'):
      for ep in ep_server.iterfind('li'):    
        if ep.get('data-openload'):      
          eps[int(ep.get("id").replace("episode-",""))] = {
            'url': ep.get("data-openload"),
            'title': ep.find('a').get('title')
          }
        elif ep.get('data-drive').startswith('https://vidcloud9.com'):      
          eps[int(ep.get("id").replace("episode-",""))] = {
            'url': ep.get("data-drive"),
            'title': ep.find('a').get('title')
          }
    return eps



@Route.register
def root(plugin, content_type="segment"):
    for e in shows:
        yield Listitem.from_dict(**{
            "label": e.get('title'),
            "art": {
                "thumb": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"icon.jpg"),
                "icon": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"icon.jpg"),
                "fanart": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"fanart.jpg"),
            },
            "callback": Route.ref("/resources/lib/main:get_all_seasons"),
            "params": {"seasons": e.get('seasons'), "id": e.get('id')}
        })

@Route.register
def get_all_seasons(plugin, seasons, id):
    for e in seasons:
        yield Listitem.from_dict(**{
            "label": e.get('title'),
            "art": {
                "thumb": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
                "icon": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
                "fanart": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"fanart.jpg"),
            },
            "callback": Route.ref("/resources/lib/main:get_all_episodes"),
            "params": {"url": e.get('url'), "id": id}
        })        


@Route.register
def get_all_episodes(plugin, url, id):

    all_episodes = get_episodes(url=url)    
    for i in sorted(all_episodes.keys()):
        ep = all_episodes[i]
        item = Listitem()

        item.label = ep['title']
        item.art['thumb'] = os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
        item.art['fanart'] = os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"fanart.jpg"),
        item.set_callback(play_video, title=ep['title'], url=ep['url'])
        yield item


@Resolver.register
def play_video(plugin, title, url):
    headers={
      "X-Requested-With":"XMLHttpRequest",
      "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36."
    }
    ep_resp = urlquick.get(url.replace('streaming','ajax'), max_age=-1, verify = False, headers=headers)
    source_json = ep_resp.json()

    cb_url = source_json['source'][0]['file']
    return Listitem().from_dict(**{
        'label': title,
        'callback': cb_url
    })
