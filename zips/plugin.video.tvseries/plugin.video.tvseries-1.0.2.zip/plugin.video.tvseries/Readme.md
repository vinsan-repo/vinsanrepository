# F.R.I.E.N.D.S

This is a simple yet fully functional video plugin of [F.R.I.E.N.D.S](https://www.imdb.com/title/tt0108778/).

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
 
