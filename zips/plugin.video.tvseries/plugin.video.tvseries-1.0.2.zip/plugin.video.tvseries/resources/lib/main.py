# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from codequick.script import Settings
import urlquick
import xbmc
import xbmcgui
import xbmcaddon
import re
import os

ADDON = xbmcaddon.Addon()
baseUrl = Settings.get_string('mh_base_url')
shows = [
  {
    'title': 'Money Heist',
    'id': 'moneyheist',
    'seasons': [
      {
        'title': 'Season 01',
        'url': 'https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-1-online-english/'
      },
      {
          'title': 'Season 02',
          'url': 'https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-2-online-english/'
      },
      {
          'title': 'Season 03',
          'url': 'https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-3-online-english/'
      },
      {
          'title': 'Season 03',
          'url': 'https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-4-online-english/'
      }
    ]
  }
]

def get_mh_episodes(url):
  eps = []
  resp = urlquick.get(url, max_age=-1, verify = False)  
  episode_list = resp.parse("ul", attrs={"class": "su-subpages"})
  for ep in episode_list.iterfind('li'):
    eps.append({
      'title': ep.find('a').text,
      'url': ep.find('a').get('href')
    })
  return eps

def get_episodes(url):    
    resp = urlquick.get(f'{url}', max_age=-1, verify=False)
    episode_list = resp.parse("div", attrs={"class": "pas-list"})
    eps = {}
    for ep_server in episode_list.iterfind('ul'):
      for ep in ep_server.iterfind('li'):    
        if ep.get('data-openload'):      
          eps[int(ep.get("id").replace("episode-",""))] = {
            'url': ep.get("data-openload"),
            'title': ep.find('a').get('title')
          }
        elif ep.get('data-drive').startswith('https://vidcloud9.com'):      
          eps[int(ep.get("id").replace("episode-",""))] = {
            'url': ep.get("data-drive"),
            'title': ep.find('a').get('title')
          }
    return eps



@Route.register
def root(plugin, content_type="segment"):
    for e in shows:
        yield Listitem.from_dict(**{
            "label": e.get('title'),
            "art": {
                "thumb": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"icon.jpg"),
                "icon": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"icon.jpg"),
                "fanart": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",e.get('id'),"fanart.jpg"),
            },
            "callback": Route.ref("/resources/lib/main:get_all_seasons"),
            "params": {"seasons": e.get('seasons'), "id": e.get('id')}
        })

@Route.register
def get_all_seasons(plugin, seasons, id):
    for e in seasons:
        yield Listitem.from_dict(**{
            "label": e.get('title'),
          "art": {
                "thumb": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
                "icon": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
                "fanart": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"fanart.jpg"),
            },
            "callback": Route.ref("/resources/lib/main:get_all_episodes"),
            "params": {"url": e.get('url'), "id": id}
        })        


@Route.register
def get_all_episodes(plugin, url, id):

    all_episodes = get_mh_episodes(url=url)    
    for ep in all_episodes:        
        item = Listitem()

        item.label = ep['title']
        item.art['thumb'] = os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"icon.jpg"),
        item.art['fanart'] = os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "resources","images",id,"fanart.jpg"),
        item.set_callback(play_mh_video, title=ep['title'], url=ep['url'])
        yield item

@Resolver.register
def play_mh_video(plugin, title, url):
    
    ep_resp = urlquick.get(url, max_age=-1, verify = False,)
    episode_list = ep_resp.parse("div",attrs={'class':'e-hosted-video elementor-wrapper elementor-fit-aspect-ratio elementor-open-inline'})
    
    cb_url = episode_list.find('video').get('src')
    return Listitem().from_dict(**{
        'label': title,
        'callback': cb_url
    })

@Resolver.register
def play_video(plugin, title, url):
    headers={
      "X-Requested-With":"XMLHttpRequest",
      "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36."
    }
    ep_resp = urlquick.get(url.replace('streaming','ajax'), max_age=-1, verify = False, headers=headers)
    source_json = ep_resp.json()

    cb_url = f'{source_json["source"][0]["file"]}|Referer="https://www.mytrustworth.com"'
    return Listitem().from_dict(**{
        'label': title,
        'callback': cb_url
    })
