import urlquick
import re
import json
import ast

headers={
  "X-Requested-With":"XMLHttpRequest",
  "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36."
}
# resp = urlquick.get("https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-1-online-english/", max_age=-1, verify = False)
# episode_list = resp.parse("ul", attrs={"class": "su-subpages"})

# # # eps = {}
# for ep in episode_list.iterfind('li'):
#   print(ep.find('a').text)



resp = urlquick.get("https://www.mytrustworth.com/literature/seasons/english-seasons/money-heist-online-english/money-heist-season-1-online-english/money-heist-season-1-episode-8-online-english/", max_age=-1, verify = False)
episode_list = resp.parse("div",attrs={'class':'e-hosted-video elementor-wrapper elementor-fit-aspect-ratio elementor-open-inline'})
print(episode_list.find('video').get('src'))
# for ep in episode_list.iterfind('video'):
#   print(ep.get('src'))
# eps = {}
# for ep in episode_list.iterfind('li'):
#   print(ep.find('a').get('href'))  
#  for ep in ep_server.iterfind('a'):    
#     if ep.get('data-openload'):      
#       eps[int(ep.get("id").replace("episode-",""))] = {
#         'url': ep.get("data-openload"),
#         'title': ep.find('a').get('title')
#       }
#     elif ep.get('data-drive').startswith('https://vidcloud9.com'):      
#       eps[int(ep.get("id").replace("episode-",""))] = {
#         'url': ep.get("data-drive"),
#         'title': ep.find('a').get('title')
#       }
# for i in sorted(eps.keys()):
#   print(eps[i])

# ep_resp = urlquick.get("https://vidcloud9.com/streaming.php?id=MTU3OTgw&title=Money+Heist+-+Season+1+Episode+8&typesub=SUB&sub=L21vbmV5LWhlaXN0LXNlYXNvbi0xLWVwaXNvZGUtOC9tb25leS1oZWlzdC1zZWFzb24tMS1lcGlzb2RlLTgudnR0&cover=Y292ZXIvbW9uZXktaGVpc3QucG5n".replace('streaming','ajax'), max_age=-1, verify = False, headers=headers)
# print(ep_resp.json())
  
#//streamtape.com/get_video?id=WrMWewz7g7cbVGq&expires=1623164842&ip=F0SUKREUKxSHDN&token=5vq89eKNOszZ