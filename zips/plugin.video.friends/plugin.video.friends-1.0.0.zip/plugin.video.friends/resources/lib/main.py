# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, run
from codequick.utils import urljoin_partial, bold
from codequick.script import Settings
import urlquick
import xbmc
import xbmcgui
import xbmcaddon
import re
import os

ADDON = xbmcaddon.Addon()
baseUrl = 'https://dl1.zoopix.ir'
seasons = [
    {
        'title': 'Season 01',
        'url': f'{baseUrl}/Series/Friends/S01/'
    },
    {
        'title': 'Season 02',
        'url': f'{baseUrl}/Series/Friends/S02/'
    },
    {
        'title': 'Season 03',
        'url': f'{baseUrl}/Series/Friends/S03/'
    },
    {
        'title': 'Season 04',
        'url': f'{baseUrl}/Series/Friends/S04/'
    },
    {
        'title': 'Season 05',
        'url': f'{baseUrl}/Series/Friends/S05/'
    },
    {
        'title': 'Season 06',
        'url': f'{baseUrl}/Series/Friends/S06/'
    },
    {
        'title': 'Season 07',
        'url': f'{baseUrl}/Series/Friends/S07/'
    },
    {
        'title': 'Season 08',
        'url': f'{baseUrl}/Series/Friends/S08/'
    },
    {
        'title': 'Season 09',
        'url': f'{baseUrl}/Series/Friends/S09/'
    },
    {
        'title': 'Season 10',
        'url': f'{baseUrl}/Series/Friends/S10/'
    },
]


def get_episodes(url):
    ep_list = []
    resp = urlquick.get(url, max_age=-1, verify=False)
    body = resp.parse("body")

    episodes = body.iterfind('.//a')
    for ep in episodes:
        if ep.get('href').endswith('.mkv'):
            ep_dict = {}
            ep_dict['title'] = ep.text
            ep_dict['url'] = f'{baseUrl}{ep.get("href")}'
            ep_list.append(ep_dict)

    return ep_list


@Route.register
def root(plugin, content_type="segment"):
    for e in seasons:
        yield Listitem.from_dict(**{
            "label": e.get('title'),
            "art": {
                "thumb": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "addon-icon.png"),
                "icon": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "addon-icon.png"),
                "fanart": os.path.join(xbmc.translatePath(ADDON.getAddonInfo("path")), "fanart.jpg"),
            },
            "callback": Route.ref("/resources/lib/main:get_all_episodes"),
            "params": {"url": e.get('url')}
        })


@Route.register
def get_all_episodes(plugin, url):

    all_episodes = get_episodes(url=url)

    for ep in all_episodes:
        item = Listitem()

        item.label = ep['title'].replace('.720p.movies.zoopix.ir.mkv','')
        item.art['thumb'] = os.path.join(xbmc.translatePath(
            ADDON.getAddonInfo("path")), "addon-icon.png")
        item.art['fanart'] = os.path.join(xbmc.translatePath(
            ADDON.getAddonInfo("path")), "fanart.jpg")
        item.set_callback(play_video, title=ep['title'], url=ep['url'])
        yield item


@Resolver.register
def play_video(plugin, title, url):
    return Listitem().from_dict(**{
        'label': title.replace('.720p.movies.zoopix.ir.mkv',''),
        'callback': url
    })
