import urlquick
import re
import json
import ast
from htmlement import HTMLement

ep_list = []
resp = urlquick.get('https://dl1.zoopix.ir/Series/Friends/S01/', max_age=-1, verify = False)
epi = resp.parse("body")
for e in epi.iterfind('.//a'):
  print(e.get('href'))
